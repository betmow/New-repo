"""Daily job: turn yesterday's 5-second collector files into 1-minute summaries and push them to your GitHub repo (so I can read them).
Needs in .env:  GH_TOKEN=<fine-grained token, Contents: read/write on the repo>   GH_REPO=Betmow/new-repo
Run by cron every night 00:10 UTC:  python rollup_push.py            (or  python rollup_push.py 2026-10-25  for a given day)"""
import os, sys, glob, subprocess, datetime as dt
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); COL = os.path.join(HERE, "collect"); REPO = os.path.join(HERE, "datarepo")
def env():
    e = dict(os.environ)
    p = os.path.join(HERE, ".env")
    if os.path.exists(p):
        for l in open(p):
            if "=" in l and not l.strip().startswith("#"): k, v = l.strip().split("=", 1); e.setdefault(k, v)
    return e
def sh(*a, cwd=None): return subprocess.run(a, cwd=cwd, check=True, capture_output=True, text=True).stdout
def roll_book(p):
    d = pd.read_csv(p, parse_dates=["time"]).set_index("time"); sums = ["buy_usd", "sell_usd", "n_trades"]
    g = d.resample("1min"); out = g.last(); out["spread_bp"] = g.spread_bp.mean(); out["spread_bp_max"] = g.spread_bp.max()
    for c in sums: out[c] = g[c].sum()
    out["big_trade"] = g.big_trade.max(); out["n_upd"] = g.n_upd.last().diff().clip(lower=0)
    t = d.bid_5 + d.ask_5; out["tot5_min"] = t.resample("1min").min(); out["tot5_max"] = t.resample("1min").max()
    return out.dropna(subset=["mid"])
def roll_liq(p):
    d = pd.read_csv(p, parse_dates=["time"]); d["time"] = d.time.dt.tz_localize(None).dt.floor("1min"); d["long_liq" ] = d.usd.where(d.side == "SELL", 0); d["short_liq"] = d.usd.where(d.side == "BUY", 0)
    return d.groupby(["time", "sym"])[["long_liq", "short_liq"]].sum().reset_index()
def main():
    day = sys.argv[1] if len(sys.argv) > 1 else (dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=1)).strftime("%Y-%m-%d"); e = env()
    token, repo = e.get("GH_TOKEN"), e.get("GH_REPO", "Betmow/new-repo")
    if not os.path.isdir(os.path.join(REPO, ".git")):
        if not token: sys.exit("set GH_TOKEN in .env"); 
        sh("git", "clone", "--depth", "1", f"https://x-access-token:{token}@github.com/{repo}.git", REPO)
    sh("git", "pull", "-q", "--rebase", cwd=REPO); n = 0
    for p in glob.glob(os.path.join(COL, "*", f"{day}.csv.gz")):
        key = os.path.basename(os.path.dirname(p)); outp = os.path.join(REPO, "collect1m", key, f"{day}.csv.xz"); os.makedirs(os.path.dirname(outp), exist_ok=True)
        if key == "liq": roll_liq(p).to_csv(outp, index=False)
        elif key.startswith("meta_"): pd.read_csv(p).to_csv(outp, index=False)
        else: roll_book(p).to_csv(outp)
        n += 1
    if not n: print("nothing for", day); return
    sh("git", "add", "collect1m", cwd=REPO); sh("git", "-c", "user.name=collector", "-c", "user.email=collector@users.noreply.github.com", "commit", "-m", f"collect1m {day}", cwd=REPO)
    sh("git", "push", "-q", cwd=REPO); print("pushed", n, "files for", day)
if __name__ == "__main__": main()
