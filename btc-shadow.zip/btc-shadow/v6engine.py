"""v7 signal + trade engine (trend sleeves now: 72h lookback, 1.0 ATR stop; reversal sleeve unchanged; v6 file name kept)
ORIGINAL DOC: v6 signal + trade engine (standalone, no research-code dependencies).
Rules = BTC model v6: ungated reversal sleeve + trend breakout sleeves on 30m / 2.5h / 5.5h candles.
All bars are Binance BTCUSDT spot 15-minute bars, index = bar OPEN time (UTC). Entry = open of the 15m bar after the signal bar closes."""
import numpy as np, pandas as pd

CO = 5.0                       # bp per side
ORIGIN = pd.Timestamp("2022-07-01", tz="UTC")   # candle grid origin (matches the backtest)
T23 = pd.Timestamp("2023-01-01", tz="UTC")
EPOCH = pd.Timestamp("1970-01-01", tz="UTC")
TREND_TFS = (30, 150, 330)     # minutes
TP = dict(Nh=72, k=1.0, atr_len=14, ema=200, buf=0.25, tp=10.0, be=4.0, maxb=960, cap=.03, floor=.003, gate=.14)
RP = dict(vol=2.5, rng=1.6, pbL=.35, pbH=.65, win=7, brk=8, stopn=16, buf=0.0, cap=.02, floor=.003,
          tp1=3.0, tp2=8.0, frac=.33, oi=-2.0, agg=.46, maxb=1920)
SLEEVES = ["R", "T30", "T150", "T330"]

def _atr(b, n):
    pc = b["close"].shift(1)
    tr = pd.concat([b["high"] - b["low"], (b["high"] - pc).abs(), (b["low"] - pc).abs()], axis=1).max(axis=1); tr.iloc[0] = np.nan
    return tr

def daily_dist(df, span=200):
    d = df["close"].resample("1D").last().dropna()
    return (d / d.ewm(span=span, adjust=False).mean() - 1).shift(1)

def _tf(df, minutes, nc=None):
    b = df.resample(f"{minutes}min", origin=ORIGIN).agg({"open": "first", "high": "max", "low": "min", "close": "last"}).dropna()
    last_close = df.index[(nc or len(df)) - 1] + pd.Timedelta(minutes=15)
    return b[b.index + pd.Timedelta(minutes=minutes) <= last_close]          # only completed candles

def trend_signals(df, minutes, dist, max_e=None, nc=None):
    """returns DataFrame(e, d, s) for one trend sleeve. e = integer position of the entry bar (bar after the candle closes)."""
    p = TP; hrs = minutes / 60; t = df.index.values
    b = _tf(df, minutes, nc); nb = max(2, int(round(p["Nh"] / hrs)))
    tr = pd.concat([b.high - b.low, (b.high - b.close.shift()).abs(), (b.low - b.close.shift()).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / p["atr_len"], adjust=False).mean().to_numpy()
    h, l, c = b.high.to_numpy(), b.low.to_numpy(), b.close.to_numpy()
    hi = pd.Series(h).rolling(nb).max().shift(1).to_numpy(); lo = pd.Series(l).rolling(nb).min().shift(1).to_numpy()
    up = c > hi + p["buf"] * atr; dn = c < lo - p["buf"] * atr
    cl = (b.index + pd.Timedelta(minutes=minutes)).values
    E = np.searchsorted(t, cl, side="left"); n = len(df); lim = n - 2 if max_e is None else max_e
    ok = np.isfinite(atr) & np.isfinite(hi) & (E <= lim) & (E < n) & (cl >= np.datetime64(T23.tz_convert(None)))
    ii = np.flatnonzero(ok & (up | dn)); d = np.where(up[ii], 1, -1); s = p["k"] * atr[ii] / c[ii]; e = E[ii]
    dd = dist.reindex(df.index[e].floor("1D")).to_numpy()
    m = (np.sign(dd) == d) & (np.abs(dd) < p["gate"]) & (s >= p["floor"]) & (s <= p["cap"])
    return pd.DataFrame(dict(e=e[m], d=d[m], s=s[m]))

def reversal_signals(df, oi24, max_e=None, nc=None):
    """oi24: Series (index = bar open time) of 24h % change of open interest, known at that bar."""
    p = RP; n = len(df); t = df.index.values
    b = df.resample("12h").agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum", "taker_buy_base": "sum"}).dropna(subset=["open"])
    b = b[b.index + pd.Timedelta(hours=12) <= df.index[(nc or len(df)) - 1] + pd.Timedelta(minutes=15)]
    c, h, l, v = b.close, b.high, b.low, b.volume
    atr = _atr(b, 14).ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    rel = (v / v.rolling(20).median().shift(1)).to_numpy(); rg = ((h - l) / atr).to_numpy()
    ma = c.rolling(20).mean(); sd = c.rolling(20).std(ddof=0); pb = ((c - (ma - 2 * sd)) / (4 * sd)).to_numpy()
    tsh = (b.taker_buy_base / b.volume).to_numpy()
    ei = np.searchsorted(t, (b.index + pd.Timedelta(hours=12)).values, side="left")
    h15, l15, c15, o15 = (df[k].to_numpy(float) for k in ("high", "low", "close", "open"))
    hhb = pd.Series(h15).rolling(p["brk"]).max().shift(1).to_numpy(); llb = pd.Series(l15).rolling(p["brk"]).min().shift(1).to_numpy()
    hhs = pd.Series(h15).rolling(p["stopn"]).max().to_numpy(); lls = pd.Series(l15).rolling(p["stopn"]).min().to_numpy()
    lim = n - 2 if max_e is None else max_e; out = []
    for d, msk in ((1, (rel >= p["vol"]) & (rg >= p["rng"]) & (pb < p["pbL"])), (-1, (rel >= p["vol"]) & (rg >= p["rng"]) & (pb > p["pbH"]))):
        for i in np.flatnonzero(msk):
            if ei[i] > lim or b.index[i] < T23: continue
            t0 = int(ei[i]); exp = t0 + p["win"] * 96; zc = float(b.close.iloc[i])
            j0 = max(t0 - 1, 0); j1 = min(exp, n - 1) + 1          # bars whose close lies in [zone start, zone end]
            for j in range(j0, min(j1, n - 1)):
                if j + 1 >= n: break
                if d == -1:
                    if c15[j] < llb[j] and hhs[j] >= zc:
                        E = o15[j + 1]; s = (hhs[j] * (1 + p["buf"]) - E) / E
                        if p["floor"] <= s <= p["cap"]: out.append((j + 1, -1, s, tsh[i])); break
                else:
                    if c15[j] > hhb[j] and lls[j] <= zc:
                        E = o15[j + 1]; s = (E - lls[j] * (1 - p["buf"])) / E
                        if p["floor"] <= s <= p["cap"]: out.append((j + 1, 1, s, tsh[i])); break
    S = pd.DataFrame(out, columns=["e", "d", "s", "tsh"])
    if len(S) == 0: return S[["e", "d", "s"]]
    S = S[S.e <= lim]; agg = np.where(S.d == 1, S.tsh, 1 - S.tsh)
    o = oi24.reindex(df.index[S.e.to_numpy()] - pd.Timedelta("15min")).to_numpy()
    m = (agg >= p["agg"]) & np.isfinite(o) & (o >= p["oi"]) & (df.index[S.e.to_numpy()] >= T23)
    return S[m][["e", "d", "s"]].sort_values("e").reset_index(drop=True)

def make_oi24(oi_sum, index):
    g = oi_sum.reindex(pd.date_range(index[0], index[-1], freq="15min")).ffill(limit=8)
    return g.pct_change(96, fill_method=None) * 100

def sim_trade(O, H, L, C, e, d, s, tp=None, maxb=10**9, be=None):
    """Port of the backtest simulator. Returns (exit_idx, gross_return, reason). reason 'open' = still running (not enough bars)."""
    N = len(O)
    if e >= N: return None
    L_ = min(e + maxb, N) - e; nev = L_; E = O[e]
    Hw, Lw, Ow = H[e:e + nev], L[e:e + nev], O[e:e + nev]; big = nev + 1
    if d == 1:
        tl = np.full(nev, E * (1 - s))
        if be:
            cmb = np.maximum.accumulate(Hw); armed = np.concatenate([[False], cmb[:-1] >= E * (1 + be * s)]); tl = np.where(armed, np.maximum(tl, E), tl)
        hs = np.flatnonzero(Lw <= tl); js = hs[0] if len(hs) else big; jt = big
        if tp: ht = np.flatnonzero(Hw >= E * (1 + tp)); jt = ht[0] if len(ht) else big
    else:
        tl = np.full(nev, E * (1 + s))
        if be:
            cmb = np.minimum.accumulate(Lw); armed = np.concatenate([[False], cmb[:-1] <= E * (1 - be * s)]); tl = np.where(armed, np.minimum(tl, E), tl)
        hs = np.flatnonzero(Hw >= tl); js = hs[0] if len(hs) else big; jt = big
        if tp: ht = np.flatnonzero(Lw <= E * (1 - tp)); jt = ht[0] if len(ht) else big
    if js == big and jt == big:
        return (e + nev - 1, d * (C[e + nev - 1] - E) / E, "open" if (e + maxb > N) else "time")
    if js <= jt:
        j = js; X = min(tl[j], Ow[j]) if d == 1 else max(tl[j], Ow[j]); why = "stop"
    else:
        j = jt; X = max(E * (1 + tp), Ow[j]) if d == 1 else min(E * (1 - tp), Ow[j]); why = "target"
    return e + j, d * (X - E) / E, why

def trade_result(df, sleeve, e, d, s):
    """Simulate a trade on the bars available. Returns dict(status, exit_idx, R, gross, legs)."""
    O, H, L, C = (df[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    if sleeve == "R":
        legs = []
        for fr, tp, be in ((RP["frac"], RP["tp1"], None), (1 - RP["frac"], RP["tp2"], RP["tp1"])):
            o = sim_trade(O, H, L, C, e, d, s, tp=tp * s, maxb=RP["maxb"], be=be)
            if o is None: return None
            legs.append((fr, o))
    else:
        o = sim_trade(O, H, L, C, e, d, s, tp=TP["tp"] * s, maxb=TP["maxb"], be=TP["be"])
        if o is None: return None
        legs = [(1.0, o)]
    g = sum(fr * o[1] for fr, o in legs); xm = max(o[0] for _, o in legs); opn = any(o[2] == "open" for _, o in legs)
    return dict(status="open" if opn else "closed", exit_idx=xm, gross=g, R=(g - 2 * CO / 1e4) / s, legs=[(fr, o[2]) for fr, o in legs])

def all_signals(df, oi24, live=False, dist=None):
    """live=True: df's LAST row is a placeholder for the bar that is opening now (open known, rest = open); signals may enter on it.
    Returns {sleeve: DataFrame(e, d, s)} with e = integer position in df."""
    dist = daily_dist(df) if dist is None else dist; out = {}
    nc = len(df) - 1 if live else None; mx = nc if live else None
    out["R"] = reversal_signals(df, oi24, mx, nc)
    for m in TREND_TFS: out[f"T{m}"] = trend_signals(df, m, dist, mx, nc)
    return out

def sequence(df, sig, sleeve):
    """one slot per sleeve: a signal is taken only if flat; blocked while e <= exit_idx + 1. Returns DataFrame of trades (closed or open)."""
    rows = []; busy_until = -1
    for r in sig.sort_values("e", kind="stable").itertuples():
        if r.e <= busy_until: continue
        res = trade_result(df, sleeve, int(r.e), int(r.d), float(r.s))
        if res is None: continue
        rows.append(dict(sleeve=sleeve, e=int(r.e), d=int(r.d), s=float(r.s), x=res["exit_idx"], R=res["R"], status=res["status"]))
        busy_until = 10**12 if res["status"] == "open" else res["exit_idx"] + 1
    return pd.DataFrame(rows)

def rsi5h_dir(df, d, entry_time, minutes=300, n=14):
    """RSI(14) of 5-hour candles known at entry_time (last COMPLETED candle), measured in the trade direction
    (long: RSI; short: 100-RSI). High = strong momentum with the trade. Uses closed bars only."""
    b = df.resample(f"{minutes}min", origin=ORIGIN).agg({"close": "last"}).dropna(); cl = b.index + pd.Timedelta(minutes=minutes)
    b = b[cl <= entry_time]
    if len(b) < n + 2: return float("nan")
    dlt = b.close.diff(); up = dlt.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean(); dn = (-dlt.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    r = float((100 - 100 / (1 + up / dn)).iloc[-1]); return r if d == 1 else 100 - r
def tier(sleeve, hr):
    """experimental sizing tier (see report): A = trend trade with RSI5h momentum >= 60 in trade direction, B = other trend trade, R = reversal"""
    if sleeve == "R": return "R"
    return "A" if (hr == hr and hr >= 60) else "B"
TIER_MULT = {"A": 1.25, "B": 0.85, "R": 1.0}      # suggested multiples of the base 1R (unvalidated, shadow-test only)
