"""One-time Telegram setup.  1) In Telegram talk to @BotFather, send /newbot, copy the token.  2) Open your new bot and send it any message (e.g. "hi").
3) Run:  python3 tg_setup.py YOUR_TOKEN        -> finds your chat id, sends a test message, writes .env"""
import sys, requests
tok = sys.argv[1].strip()
r = requests.get(f"https://api.telegram.org/bot{tok}/getUpdates", timeout=20).json()
if not r.get("ok"): sys.exit(f"Telegram rejected the token: {r}")
chats = [u["message"]["chat"] for u in r["result"] if "message" in u]
if not chats: sys.exit("No messages found. Open your bot in Telegram, send it 'hi', then run this again.")
chat = chats[-1]["id"]
x = requests.post(f"https://api.telegram.org/bot{tok}/sendMessage", data=dict(chat_id=chat, text="Shadow bot alerts are connected."), timeout=20).json()
if not x.get("ok"): sys.exit(f"Send failed: {x}")
open(".env", "a").write(f"TG_TOKEN={tok}\nTG_CHAT={chat}\n"); print("OK: test message sent and .env written (chat id", chat, ")")
