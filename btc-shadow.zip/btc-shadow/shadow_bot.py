#!/usr/bin/env python3
"""BTC v7 SHADOW BOT: generates v7 signals live (Binance USD-M PERP prices) and follows them as virtual trades. It places NO orders and needs NO API keys.

  python shadow_bot.py            run once (use with cron / launchd every 15 minutes, a few seconds after :00 :15 :30 :45)
  python shadow_bot.py --loop     run forever, waking up 20 s after every quarter hour
  python shadow_bot.py --status   print open trades and results
  python shadow_bot.py --replay 2026-09-01 [2026-10-19]   offline self-test on local history (needs shadow_data/btc_15min.csv and oi.pkl/oi.csv)

Data: Binance public market data only (fapi.binance.com perp klines + open-interest history, data.binance.vision for the bootstrap). Files live in ./shadow_data
Optional alerts: set TG_TOKEN and TG_CHAT (Telegram bot) in the environment."""
import os, sys, io, json, time, zipfile, argparse, datetime as dt
import numpy as np, pandas as pd
import v6engine as V

DATA = os.environ.get("SHADOW_DIR", "shadow_data"); os.makedirs(DATA, exist_ok=True)
F_BARS, F_OI, F_STATE, F_TRADES, F_LOG = (f"{DATA}/{n}" for n in ("btc_15min_perp.csv", "oi_live.csv", "state.json", "shadow_trades.csv", "shadow.log"))
COLS = ["open", "high", "low", "close", "volume", "quote_volume", "trades", "taker_buy_base"]
TAIL = 15000; FEE_EXTRA = 0.001   # info only: 1R in dollars for the size column
FAPI = "https://fapi.binance.com"; VISION = "https://data.binance.vision/data/futures/um"

def load_env():
    """reads KEY=VALUE lines from .env next to the script (TG_TOKEN, TG_CHAT, RISK_USD)"""
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(p):
        for ln in open(p):
            ln = ln.strip()
            if ln and not ln.startswith("#") and "=" in ln:
                k, v = ln.split("=", 1); os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
load_env()
RISK_USD = float(os.environ.get("RISK_USD", "1.0"))
def log(*a):
    m = f"{dt.datetime.now(dt.timezone.utc):%Y-%m-%d %H:%M:%S}Z " + " ".join(str(x) for x in a); print(m, flush=True)
    open(F_LOG, "a").write(m + "\n")
def notify(msg):
    log("ALERT", msg); tok, chat = os.environ.get("TG_TOKEN"), os.environ.get("TG_CHAT")
    if tok and chat:
        try:
            import requests; requests.post(f"https://api.telegram.org/bot{tok}/sendMessage", data=dict(chat_id=chat, text=msg), timeout=15)
        except Exception as e: log("telegram failed", e)

# ----------------------------------------------------------------------------------------- data
def _get(url, **kw):
    import requests
    for i in range(4):
        try:
            r = requests.get(url, timeout=30, **kw)
            if r.status_code == 404: return None
            r.raise_for_status(); return r
        except Exception as e:
            if i == 3: log("GET failed", url, e); return None
            time.sleep(2 * (i + 1))
def _klines_to_df(rows):
    d = pd.DataFrame(rows, columns=["ot", "open", "high", "low", "close", "volume", "ct", "quote_volume", "trades", "taker_buy_base", "tbq", "ig"])
    ot = d.ot.astype("int64"); ot = ot.where(ot < 10**14, ot // 1000)
    d.index = pd.to_datetime(ot, unit="ms", utc=True); d.index.name = "timestamp"
    return d[COLS].astype(float)
def bootstrap():
    """downloads 2022-07 -> now from the Binance data portal (about 5 min)."""
    parts = []; today = dt.date.today(); y, m = 2022, 7
    while (y, m) < (today.year, today.month):
        r = _get(f"{VISION}/monthly/klines/BTCUSDT/15m/BTCUSDT-15m-{y}-{m:02d}.zip")
        if r is not None:
            z = zipfile.ZipFile(io.BytesIO(r.content)); parts.append(_klines_to_df(pd.read_csv(io.BytesIO(z.read(z.namelist()[0])), header=None).values.tolist())); log("bootstrap", y, m)
        m += 1
        if m == 13: y, m = y + 1, 1
    d = dt.date(today.year, today.month, 1)
    while d < today:
        r = _get(f"{VISION}/daily/klines/BTCUSDT/15m/BTCUSDT-15m-{d}.zip")
        if r is not None:
            z = zipfile.ZipFile(io.BytesIO(r.content)); parts.append(_klines_to_df(pd.read_csv(io.BytesIO(z.read(z.namelist()[0])), header=None).values.tolist()))
        d += dt.timedelta(days=1)
    df = pd.concat(parts); df = df[~df.index.duplicated()].sort_index(); df.to_csv(F_BARS); return df
def load_bars():
    if not os.path.exists(F_BARS): log("no history file, bootstrapping"); return bootstrap()
    d = pd.read_csv(F_BARS, index_col=0, parse_dates=True); d.index = pd.to_datetime(d.index, utc=True); return d[COLS]
def update_bars(df):
    """append closed bars; returns (df, open_of_forming_bar)."""
    forming = None
    while True:
        start = int(df.index[-1].timestamp() * 1000) + 900_000
        r = _get(f"{FAPI}/fapi/v1/klines", params=dict(symbol="BTCUSDT", interval="15m", startTime=start, limit=1000))
        if r is None: break
        rows = r.json()
        if not rows: break
        new = _klines_to_df(rows); now_ms = time.time() * 1000
        closed = [i for i, rw in enumerate(rows) if rw[6] < now_ms]; forming_rows = [rw for rw in rows if rw[6] >= now_ms]
        if forming_rows: forming = float(forming_rows[0][1])
        new = new.iloc[closed]
        if len(new) == 0: break
        df = pd.concat([df, new]); df = df[~df.index.duplicated()]
        if len(rows) < 1000: break
    df.to_csv(F_BARS); return df, forming
def update_oi():
    old = pd.read_csv(F_OI, index_col=0, parse_dates=True).iloc[:, 0] if os.path.exists(F_OI) else pd.Series(dtype=float)
    if len(old): old.index = pd.to_datetime(old.index, utc=True)
    r = _get(f"{FAPI}/futures/data/openInterestHist", params=dict(symbol="BTCUSDT", period="15m", limit=500))
    if r is not None and r.json():
        j = pd.DataFrame(r.json()); s = pd.Series(j.sumOpenInterest.astype(float).values, index=pd.to_datetime(j.timestamp.astype("int64"), unit="ms", utc=True))
        old = pd.concat([old, s]); old = old[~old.index.duplicated(keep="last")].sort_index()
    old.to_csv(F_OI, header=["sum_open_interest"]); return old

# ----------------------------------------------------------------------------------------- state
def load_state():
    return json.load(open(F_STATE)) if os.path.exists(F_STATE) else {}
def load_trades():
    return pd.read_csv(F_TRADES, parse_dates=["entry_time", "exit_time"]).to_dict("records") if os.path.exists(F_TRADES) else []
def save_trades(T):
    cols = ["sleeve", "entry_time", "dir", "entry", "stop_pct", "stop", "size_btc_at_risk", "rsi5h_dir", "tier", "status", "exit_time", "R", "mark_R", "legs"]
    pd.DataFrame(T, columns=cols).to_csv(F_TRADES, index=False)

def evaluate(df, t):
    """follow one virtual trade on closed bars. returns dict(status, exit_idx, R)."""
    if t["entry_time"] not in df.index: return dict(status="open", exit_idx=10**12, R=0.0, legs="")
    e = df.index.get_loc(t["entry_time"]); res = V.trade_result(df, t["sleeve"], e, int(t["dir"]), float(t["stop_pct"]))
    if res is None: return dict(status="open", exit_idx=10**12, R=0.0, legs="")
    return dict(status=res["status"], exit_idx=res["exit_idx"], R=res["R"], legs="/".join(f"{fr:.2f}:{w}" for fr, w in res["legs"]))

def cycle(df, entry_open, oi, trades, state, quiet=False):
    """df = closed bars. entry_open = open price of the bar that just started. Mutates trades/state; returns list of alert strings."""
    msgs = []; ph = pd.DataFrame({k: [entry_open] for k in ("open", "high", "low", "close")}, index=[df.index[-1] + pd.Timedelta(minutes=15)]); ph["volume"] = 0.; ph["taker_buy_base"] = 0.
    sub = pd.concat([df.iloc[-TAIL:], ph]); dist = V.daily_dist(pd.concat([df, ph]))
    oi24 = V.make_oi24(oi, sub.index) if len(oi) else pd.Series(np.nan, index=sub.index)
    sig = V.all_signals(sub, oi24, live=True, dist=dist)
    last_seen = pd.Timestamp(state["last_entry_time"]) if "last_entry_time" in state else sub.index[-1]
    # 1) refresh all trades
    for t in trades:
        was = t["status"]; r = evaluate(df, t); t["status"] = r["status"]; t["mark_R"] = round(r["R"], 3); t["legs"] = r["legs"]
        if r["status"] == "closed":
            t["R"] = round(r["R"], 3); t["exit_time"] = df.index[min(r["exit_idx"], len(df) - 1)]
            if was != "closed": msgs.append(f"CLOSED {t['sleeve']} {'LONG' if t['dir']==1 else 'SHORT'} entry {t['entry']:.0f} -> R {t['R']:+.2f} ({t['legs']})")
    # 2) new signals on bars after the last one processed (normally exactly the bar that just opened)
    for sl in V.SLEEVES:
        S = sig[sl]; S = S[sub.index[S.e.to_numpy()] > last_seen] if len(S) else S
        for r in S.sort_values("e").itertuples():
            et = sub.index[r.e]; mine = [t for t in trades if t["sleeve"] == sl]
            if mine:
                lt = mine[-1]
                if lt["status"] != "closed": continue
                xi = df.index.get_loc(lt["exit_time"]); ei = df.index.get_loc(et) if et in df.index else len(df)
                if ei <= xi + 1: continue
            E = float(sub.open.iloc[r.e]); stop = E * (1 - r.s) if r.d == 1 else E * (1 + r.s)
            hr = V.rsi5h_dir(df, int(r.d), et); tr_ = V.tier(sl, hr); mult = V.TIER_MULT[tr_]
            t = dict(sleeve=sl, entry_time=et, dir=int(r.d), entry=E, stop_pct=float(r.s), stop=stop, size_btc_at_risk=round(RISK_USD / (r.s + FEE_EXTRA) / E, 5), rsi5h_dir=round(hr, 1), tier=tr_,
                     status="open", exit_time=pd.NaT, R=np.nan, mark_R=0.0, legs=""); trades.append(t)
            msgs.append(f"NEW {sl} {'LONG' if r.d==1 else 'SHORT'} @ {E:.0f}  stop {stop:.0f} ({r.s*100:.2f}%)  size at 1R=${RISK_USD:g}: {t['size_btc_at_risk']} BTC")
    try:
        import swing; msgs += swing.update(sub, df, dist, state, evaluate)
    except Exception as ex: log("swing error", repr(ex))
    state["last_entry_time"] = str(sub.index[-1]); state["last_run"] = str(dt.datetime.now(dt.timezone.utc)); return msgs

def status(trades):
    try:
        import swing; swing.status()
    except Exception: pass
    if not trades: print("no virtual trades yet"); return
    T = pd.DataFrame(trades); c = T[T.status == "closed"]; o = T[T.status != "closed"]
    print(f"closed {len(c)}  total R {c.R.sum():+.2f}   open {len(o)}  open mark R {o.mark_R.astype(float).sum():+.2f}")
    if len(c): print(c.groupby("sleeve").R.agg(["size", "sum", "mean"]).round(2))
    if len(o): print(o[["sleeve", "entry_time", "dir", "entry", "stop", "mark_R"]].to_string(index=False))

# ----------------------------------------------------------------------------------------- run modes
def run_once():
    df = load_bars(); df, forming = update_bars(df)
    if forming is None: log("no forming bar returned (API problem?)"); return
    age = (pd.Timestamp.now(tz="UTC") - (df.index[-1] + pd.Timedelta(minutes=15))).total_seconds() / 60
    if age > 45: notify(f"WARNING data is {age:.0f} min behind")
    oi = update_oi(); trades = load_trades(); state = load_state()
    first = "last_run" not in state
    for m in cycle(df, forming, oi, trades, state): notify(m)
    now = dt.datetime.now(dt.timezone.utc)
    if first: notify(f"v7 shadow bot started (perp prices; swing sleeve is paper-only). Last bar {df.index[-1]:%Y-%m-%d %H:%M} UTC. I will message you on every new signal and every close.")
    elif now.hour >= 6 and state.get("hb_date") != str(now.date()):
        c = [t for t in trades if t["status"] == "closed"]; o = [t for t in trades if t["status"] != "closed"]
        notify(f"Daily check {now:%Y-%m-%d}: bot alive, last bar {df.index[-1]:%H:%M} UTC. Closed {len(c)} trades ({sum(float(t['R']) for t in c):+.1f}R), open {len(o)}."); state["hb_date"] = str(now.date())
    save_trades(trades); json.dump(state, open(F_STATE, "w")); log("ok bars", len(df), "last", df.index[-1], "open", sum(t["status"] != "closed" for t in trades))
def loop():
    while True:
        try: run_once()
        except Exception as e: notify(f"ERROR {e!r}")
        now = time.time(); time.sleep(900 - (now % 900) + 20)
def replay(start, end=None, bars_path=None, oi_path=None):
    df = pd.read_csv(bars_path or F_BARS, index_col=0, parse_dates=True); df.index = pd.to_datetime(df.index, utc=True)
    oi = pd.read_pickle(oi_path).sum_open_interest if oi_path else pd.read_csv(F_OI, index_col=0, parse_dates=True).iloc[:, 0]
    k0 = df.index.searchsorted(pd.Timestamp(start, tz="UTC")); k1 = df.index.searchsorted(pd.Timestamp(end, tz="UTC")) if end else len(df) - 1
    os.environ["SWING_OFF"] = "1"; trades = []; state = {"last_entry_time": str(df.index[k0])}; n = 0
    full_dist = V.daily_dist(df)
    global RISK_USD
    for k in range(k0, k1):
        m = cycle_fast(df.iloc[:k], float(df.open.iloc[k]), oi, trades, state, full_dist); n += len(m)
    return pd.DataFrame(trades)
def cycle_fast(df, entry_open, oi, trades, state, full_dist):
    orig = V.daily_dist; V.daily_dist = lambda d: full_dist.loc[:d.index[-1]]
    try: return cycle(df, entry_open, oi, trades, state)
    finally: V.daily_dist = orig

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--loop", action="store_true"); ap.add_argument("--status", action="store_true"); ap.add_argument("--replay", nargs="+")
    a = ap.parse_args()
    if a.status: status(load_trades())
    elif a.replay:
        T = replay(*a.replay); print(T[["sleeve", "entry_time", "dir", "entry", "stop_pct", "status", "R"]].to_string()); status(T.to_dict("records"))
    elif a.loop: loop()
    else: run_once()
