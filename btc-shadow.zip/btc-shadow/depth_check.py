"""Compares the collector's +-1% depth with Binance's own bookDepth file for the same day (run 2 days after the collector started).
  python depth_check.py [YYYY-MM-DD]      default = 2 days ago.  Needs internet to data.binance.vision.
Prints PASS/FAIL: the swing score was built on Binance's numbers, so the collector must reproduce them."""
import sys, io, zipfile, datetime as dt, requests, numpy as np, pandas as pd
day = sys.argv[1] if len(sys.argv) > 1 else str(dt.date.today() - dt.timedelta(days=2))
r = requests.get(f"https://data.binance.vision/data/futures/um/daily/bookDepth/BTCUSDT/BTCUSDT-bookDepth-{day}.zip", timeout=60); r.raise_for_status()
z = zipfile.ZipFile(io.BytesIO(r.content)); B = pd.read_csv(z.open(z.namelist()[0])); B["time"] = pd.to_datetime(B.timestamp, utc=True); B["p"] = B.percentage.astype(float)
bb = B[B.p == -1].set_index("time").notional.resample("1min").last(); ba = B[B.p == 1].set_index("time").notional.resample("1min").last()
C = pd.read_csv(f"collect/perp_BTCUSDT/{day}.csv.gz", usecols=["time", "bid_1", "ask_1", "cov_bid", "cov_ask"]); C["time"] = pd.to_datetime(C.time, utc=True); C = C.set_index("time").resample("1min").last()
j = pd.concat([bb.rename("b_bin"), ba.rename("a_bin"), C.bid_1.rename("b_col"), C.ask_1.rename("a_col"), C.cov_bid, C.cov_ask], axis=1).dropna()
I = lambda b, a: (b - a) / (b + a); ratio_b = (j.b_col / j.b_bin).median(); ratio_a = (j.a_col / j.a_bin).median(); corr = np.corrcoef(I(j.b_bin, j.a_bin), I(j.b_col, j.a_col))[0, 1]
print(f"{day}: {len(j)} common minutes | collector/Binance depth ratio  bids {ratio_b:.2f}  asks {ratio_a:.2f} | correlation of +-1% imbalance {corr:.2f} | book coverage seen by collector: bid {j.cov_bid.median():.2f}%  ask {j.cov_ask.median():.2f}%")
ok = 0.85 <= ratio_b <= 1.15 and 0.85 <= ratio_a <= 1.15 and corr >= 0.8 and j.cov_bid.median() >= 1 and j.cov_ask.median() >= 1
print("PASS: collector reproduces Binance's +-1% depth" if ok else "FAIL: do not trust the swing flag yet (send me this line)")
