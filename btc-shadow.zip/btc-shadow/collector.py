"""Order-book / flow collector for BTCUSDT and ETHUSDT, spot and USD-M perp (Binance).
Keeps a live copy of each order book from the websocket diff stream and writes, every SNAP seconds, one row per book:
mid, best bid/ask, spread, microprice, depth (USD) inside +-0.1/0.25/0.5/1/2/3/5 %, how far the book copy really reaches (cov_*),
plus taker buy/sell volume, trade count and biggest trade since the last row. Liquidations (perp) are saved as events.
Run:  python collector.py            (forever)      python collector.py --selftest      python collector.py --probe (60 s, prints coverage)
Output: ./collect/<market>_<sym>/<YYYY-MM-DD>.csv.gz   (gzip members appended; read with pandas.read_csv)
"""
import asyncio, gzip, json, os, sys, time, datetime as dt
import numpy as np
try:
    import aiohttp
except ImportError:
    aiohttp = None

SYMS = ["BTCUSDT", "ETHUSDT"]
BANDS = [0.1, 0.25, 0.5, 1, 2, 3, 5]
SNAP = int(os.environ.get("SNAP", 5))                       # seconds between rows
OUT = os.environ.get("COLLECT_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "collect"))
# Binance moved USD-M websockets to /public (order book) and /market (trades, liquidations). Override with env if they change again.
PERP_PUB = os.environ.get("PERP_PUB", "wss://fstream.binance.com/public/stream")
PERP_MKT = os.environ.get("PERP_MKT", "wss://fstream.binance.com/market/stream")
SPOT_WS = os.environ.get("SPOT_WS", "wss://stream.binance.com:9443/stream")
REST = {"perp": "https://fapi.binance.com/fapi/v1/depth?symbol={s}&limit=1000", "spot": "https://api.binance.com/api/v3/depth?symbol={s}&limit=5000"}

class Book:
    """Local order book kept in sync with Binance's diff-depth stream (official procedure)."""
    def __init__(self, market):
        self.market = market; self.reset()
    def reset(self):
        self.bids = {}; self.asks = {}; self.synced = False; self.snap_id = None; self.prev_u = None; self.buf = []; self.n_upd = 0
    def load_snapshot(self, snap):
        self.bids = {float(p): float(q) for p, q in snap["bids"] if float(q) > 0}; self.asks = {float(p): float(q) for p, q in snap["asks"] if float(q) > 0}
        self.snap_id = snap["lastUpdateId"]; self.prev_u = None; self.synced = False
        buf, self.buf = self.buf, []
        for ev in buf:
            if self.feed(ev) == "gap": return "gap"
        return "ok"
    def _apply(self, ev):
        for side, d in (("b", self.bids), ("a", self.asks)):
            for p, q in ev[side]:
                p = float(p); q = float(q)
                if q == 0: d.pop(p, None)
                else: d[p] = q
        self.prev_u = ev["u"]; self.n_upd += 1
    def feed(self, ev):
        """returns 'ok' | 'drop' | 'buffered' | 'gap' (gap = must resync)"""
        if self.snap_id is None: self.buf.append(ev); return "buffered"
        if not self.synced:
            if ev["u"] <= self.snap_id: return "drop"
            if not (ev["U"] <= self.snap_id + 1 <= ev["u"]): return "gap"
            self._apply(ev); self.synced = True; return "ok"
        ok = (ev.get("pu") == self.prev_u) if self.market == "perp" else (ev["U"] == self.prev_u + 1)
        if not ok: return "gap"
        self._apply(ev); return "ok"
    def row(self):
        if not (self.synced and self.bids and self.asks): return None
        bp = np.fromiter(self.bids.keys(), float, len(self.bids)); bq = np.fromiter(self.bids.values(), float, len(self.bids))
        ap = np.fromiter(self.asks.keys(), float, len(self.asks)); aq = np.fromiter(self.asks.values(), float, len(self.asks))
        i = bp.argmax(); j = ap.argmin(); bb, ba = bp[i], ap[j]
        if bb >= ba: return None                                           # crossed = stale book
        mid = (bb + ba) / 2; r = {"mid": mid, "bid": bb, "ask": ba, "bid_qty": bq[i], "ask_qty": aq[j], "spread_bp": (ba - bb) / mid * 1e4,
                                 "micro": (bb * aq[j] + ba * bq[i]) / (bq[i] + aq[j])}
        bn = bp * bq; an = ap * aq
        for b in BANDS:
            r[f"bid_{b:g}"] = bn[bp >= mid * (1 - b / 100)].sum(); r[f"ask_{b:g}"] = an[ap <= mid * (1 + b / 100)].sum()
        r["cov_bid"] = (mid - bp.min()) / mid * 100; r["cov_ask"] = (ap.max() - mid) / mid * 100; r["n_levels"] = len(bp) + len(ap); r["n_upd"] = self.n_upd
        return r

def selftest():
    # build a fake perp stream with a gap and a spot stream, check sync + bands
    b = Book("perp"); snap = {"lastUpdateId": 100, "bids": [["99", "1"], ["98", "2"], ["95", "10"]], "asks": [["101", "1"], ["102", "3"], ["106", "5"]]}
    ev = lambda U, u, pu, bids=(), asks=(): {"U": U, "u": u, "pu": pu, "b": [list(map(str, x)) for x in bids], "a": [list(map(str, x)) for x in asks]}
    assert b.feed(ev(90, 99, 80)) == "buffered" and b.feed(ev(100, 103, 99, bids=[(99, 0), (97, 4)])) == "buffered"
    assert b.load_snapshot(snap) == "ok" and b.synced and 99.0 not in b.bids and b.bids[97.0] == 4
    assert b.feed(ev(104, 105, 103, asks=[(101, 2)])) == "ok" and b.asks[101.0] == 2
    assert b.feed(ev(107, 108, 106)) == "gap"                                  # missed 106 -> resync
    r = b.row(); assert abs(r["mid"] - (98 + 101) / 2) < 1e-9 or r["bid"] == 98.0, r                       # best bid 98 (99 removed, 97 added)
    assert r["bid"] == 98.0 and r["ask"] == 101.0
    mid = 99.5; assert abs(r["bid_5"] - (98 * 2 + 97 * 4 + 95 * 10)) < 1e-6, r["bid_5"]                      # within 5% of 99.5 -> >=94.525: 98,97,95
    assert abs(r["ask_5"] - (101 * 2 + 102 * 3 + 106 * 5 * (106 <= mid * 1.05))) < 1e-6
    s = Book("spot"); s.load_snapshot(snap); e = {"U": 101, "u": 102, "b": [], "a": []}
    assert s.feed(e) == "ok" and s.feed({"U": 103, "u": 103, "b": [], "a": []}) == "ok" and s.feed({"U": 105, "u": 105, "b": [], "a": []}) == "gap"
    t = Book("perp"); t.load_snapshot(snap); assert t.feed(ev(50, 60, 40)) == "drop" and t.feed(ev(120, 130, 119)) == "gap"
    print("selftest OK")

class Writer:
    def __init__(self): self.buf = {}; self.last_flush = time.time()
    def add(self, key, header, line, day):
        self.buf.setdefault((key, day, header), []).append(line)
    def flush(self, force=False):
        if not force and time.time() - self.last_flush < 60: return
        for (key, day, header), lines in list(self.buf.items()):
            d = os.path.join(OUT, key); os.makedirs(d, exist_ok=True); p = os.path.join(d, f"{day}.csv.gz"); new = not os.path.exists(p)
            with gzip.open(p, "ab") as f: f.write((((header + "\n") if new else "") + "\n".join(lines) + "\n").encode())
        self.buf.clear(); self.last_flush = time.time()

W = Writer(); BOOKS = {}; FLOW = {}; COLS = None
def now_utc(): return dt.datetime.now(dt.timezone.utc)
async def get_json(session, url):
    async with session.get(url, timeout=aiohttp.ClientTimeout(total=20)) as r:
        r.raise_for_status(); return await r.json()
async def resync(session, market, sym):
    b = BOOKS[(market, sym)]; keep = b.buf; b.reset(); b.buf = keep
    for _ in range(5):
        snap = await get_json(session, REST[market].format(s=sym))
        if b.load_snapshot(snap) != "gap": return
        keep = b.buf; b.reset(); b.buf = keep; await asyncio.sleep(1)
def flow_add(market, sym, e):
    f = FLOW.setdefault((market, sym), dict(buy=0.0, sell=0.0, n=0, big=0.0)); usd = float(e["p"]) * float(e["q"])
    if e["m"]: f["sell"] += usd
    else: f["buy"] += usd
    f["n"] += 1; f["big"] = max(f["big"], usd)
async def ws_loop(session, market, url, streams, handler):
    delay = 1
    while True:
        try:
            async with session.ws_connect(f"{url}?streams={'/'.join(streams)}", heartbeat=20, max_msg_size=0) as ws:
                print(now_utc().isoformat(), market, "connected", url, flush=True); delay = 1
                t_conn = time.time()
                async for msg in ws:
                    if msg.type != aiohttp.WSMsgType.TEXT: break
                    await handler(json.loads(msg.data))
                    if time.time() - t_conn > 23 * 3600: break                      # Binance drops sockets at 24h; reconnect cleanly
        except Exception as ex:
            print(now_utc().isoformat(), market, "ws error", repr(ex)[:200], flush=True)
        await asyncio.sleep(delay); delay = min(delay * 2, 60)
        for (m, s), b in BOOKS.items():
            if m == market: b.reset()
async def run():
    global COLS
    if aiohttp is None: sys.exit("pip install aiohttp numpy")
    async with aiohttp.ClientSession() as session:
        for m in ("perp", "spot"):
            for s in SYMS: BOOKS[(m, s)] = Book(m)
        async def depth_handler_for(market):
            async def h(msg):
                d = msg.get("data", msg); sym = d.get("s")
                if d.get("e") == "depthUpdate":
                    b = BOOKS.get((market, sym))
                    if b is None: return
                    st = b.feed(d)
                    if b.snap_id is None and not getattr(b, "fetching", False):
                        b.fetching = True
                        try: await resync(session, market, sym)
                        finally: b.fetching = False
                    elif st == "gap" and not getattr(b, "fetching", False):
                        b.fetching = True; b.buf = [d]; print(now_utc().isoformat(), market, sym, "gap -> resync", flush=True)
                        try: await resync(session, market, sym)
                        finally: b.fetching = False
                elif d.get("e") == "aggTrade": flow_add(market, sym, d)
                elif d.get("e") == "forceOrder":
                    o = d["o"]
                    if o["s"] in SYMS:
                        usd = float(o.get("ap") or o["p"]) * float(o.get("z") or o["q"])
                        W.add("liq", "time,sym,side,price,qty,usd", f"{now_utc().isoformat()},{o['s']},{o['S']},{o.get('ap') or o['p']},{o.get('z') or o['q']},{usd:.0f}", now_utc().strftime("%Y-%m-%d"))
            return h
        hp = await depth_handler_for("perp"); hs = await depth_handler_for("spot")
        low = [s.lower() for s in SYMS]
        tasks = [ws_loop(session, "perp", PERP_PUB, [f"{s}@depth@500ms" for s in low], hp),
                 ws_loop(session, "perp", PERP_MKT, [f"{s}@aggTrade" for s in low] + ["!forceOrder@arr"], hp),
                 ws_loop(session, "spot", SPOT_WS, [f"{s}@depth@100ms" for s in low] + [f"{s}@aggTrade" for s in low], hs), snapshots(session)]
        await asyncio.gather(*tasks)
async def snapshots(session):
    last_meta = 0; nxt = time.time() // SNAP * SNAP + SNAP
    while True:
        await asyncio.sleep(max(0, nxt - time.time())); nxt += SNAP; t = now_utc(); day = t.strftime("%Y-%m-%d")
        for (market, sym), b in BOOKS.items():
            r = b.row(); f = FLOW.pop((market, sym), dict(buy=0.0, sell=0.0, n=0, big=0.0))
            if r is None: continue
            r.update(buy_usd=f["buy"], sell_usd=f["sell"], n_trades=f["n"], big_trade=f["big"])
            keys = list(r.keys()); W.add(f"{market}_{sym}", "time," + ",".join(keys), f"{t.strftime('%Y-%m-%d %H:%M:%S')}," + ",".join(f"{r[k]:.8g}" for k in keys), day)
        if time.time() - last_meta > 60:                                    # perp funding / basis / open interest once a minute
            last_meta = time.time()
            for s in SYMS:
                try:
                    pi = await get_json(session, f"https://fapi.binance.com/fapi/v1/premiumIndex?symbol={s}"); oi = await get_json(session, f"https://fapi.binance.com/fapi/v1/openInterest?symbol={s}")
                    W.add(f"meta_{s}", "time,mark,index,funding,oi", f"{t.strftime('%Y-%m-%d %H:%M:%S')},{pi['markPrice']},{pi['indexPrice']},{pi['lastFundingRate']},{oi['openInterest']}", day)
                except Exception as ex: print("meta error", repr(ex)[:120], flush=True)
        W.flush()

if __name__ == "__main__":
    if "--selftest" in sys.argv: selftest()
    else:
        if "--probe" in sys.argv:
            SNAP = 5
            async def probe():
                task = asyncio.create_task(run()); await asyncio.sleep(75); W.flush(True)
                for (m, s), b in BOOKS.items():
                    r = b.row(); print(m, s, "synced", b.synced, "levels", len(b.bids) + len(b.asks), "coverage bid/ask %:", None if r is None else (round(r["cov_bid"], 2), round(r["cov_ask"], 2)))
                task.cancel()
            try: asyncio.run(probe())
            except (asyncio.CancelledError, KeyboardInterrupt): pass
        else: asyncio.run(run())
