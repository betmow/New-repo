"""Depth-confirmed SWING sleeve of v7 -- PAPER ONLY (never trades, only logs and sends alerts).
A swing signal = a trend breakout (30m / 2.5h / 5.5h; triggers use the ORIGINAL v6 settings 48h lookback + 1.5 ATR stop, exits 10R / break-even 4R / 10 days) on the side AGAINST the 200-day trend.
It is flagged when the depth score S4 >= 0.8, where S4 = mean of four percentile ranks (all within +-1% of price on the perp book, signed to the trade:
bids for a long, asks for a short): imbalance level, and change of (bid - ask) depth over 4h, 24h, 72h (as a fraction of the 30-day median depth).
Percentiles are measured against swing_ref.csv (the same four numbers at all 1,062 counter-trend signals in the backtest, from Binance's own bookDepth files).
Depth comes from collector.py (collect/perp_BTCUSDT/*.csv.gz). Needs >= 72 h of collector data before S4 exists; before that signals are logged with S4 = NaN."""
import os, glob, numpy as np, pandas as pd
import v6engine as V
HERE = os.path.dirname(os.path.abspath(__file__)); REF = os.path.join(HERE, "swing_ref.csv")
COLLECT = os.environ.get("COLLECT_DIR", os.path.join(HERE, "collect")); DATA = os.environ.get("SHADOW_DIR", "shadow_data")
F_LOG, F_TR = f"{DATA}/swing_log.csv", f"{DATA}/swing_trades.csv"; THR = 0.8
LOGC = ["entry_time", "sleeve", "dir", "entry", "stop_pct", "I1", "c4h", "c24h", "c72h", "S4", "cov_pct", "flag", "note"]
TRC = ["sleeve", "entry_time", "dir", "entry", "stop_pct", "stop", "S4", "status", "exit_time", "R", "mark_R", "legs"]

def depth_1m(days=34):
    fs = sorted(glob.glob(f"{COLLECT}/perp_BTCUSDT/*.csv.gz"))[-days:]
    if not fs: return None
    d = pd.concat([pd.read_csv(f, usecols=["time", "mid", "bid_1", "ask_1", "cov_bid", "cov_ask"]) for f in fs])
    d["time"] = pd.to_datetime(d["time"], utc=True); d = d.drop_duplicates("time").set_index("time").sort_index()
    return d.resample("1min").last()
def features(D, t):
    """t = entry bar open (UTC). Uses depth rows strictly before t. Returns dict or None."""
    if D is None: return None
    D = D[D.index < t]
    if len(D) < 1500 or (t - D.index[-1]) > pd.Timedelta(minutes=15): return None
    b, a, m = D.bid_1.ffill(limit=30), D.ask_1.ffill(limit=30), D.mid.ffill(limit=30); q = (b + a) / m; L = (b - a) / m
    med = q.rolling(43200, min_periods=1440).median().iloc[-1]; t0 = D.index[-1]; out = dict(I1=float((b.iloc[-1] - a.iloc[-1]) / (b.iloc[-1] + a.iloc[-1])), cov=float(min(D.cov_bid.iloc[-1], D.cov_ask.iloc[-1])))
    for w, k in ((240, "c4h"), (1440, "c24h"), (4320, "c72h")):
        tp = t0 - pd.Timedelta(minutes=w)
        if tp < D.index[0] or not np.isfinite(L.get(tp, np.nan)): out[k] = np.nan
        else: out[k] = float((L.iloc[-1] - L[tp]) / med)
    return out
def score(f, d):
    ref = pd.read_csv(REF); vals = {"I1": f["I1"] * d, "c4h": f["c4h"] * d, "c24h": f["c24h"] * d, "c72h": f["c72h"] * d}
    if any(not np.isfinite(v) for v in vals.values()): return np.nan, vals
    p = [np.searchsorted(np.sort(ref[k].dropna().to_numpy()), v) / ref[k].notna().sum() for k, v in vals.items()]
    return float(np.mean(p)), vals
def _load(p, cols, dates):
    if not os.path.exists(p): return pd.DataFrame(columns=cols)
    return pd.read_csv(p, parse_dates=dates)
def status():
    T = _load(F_TR, TRC, ["entry_time", "exit_time"])
    L = _load(F_LOG, LOGC, ["entry_time"])
    if L.empty: print("swing (paper): no counter-trend signals yet"); return
    print(f"swing (paper): counter-trend signals {len(L)}, flagged (S4>=0.8) {int(L.flag.sum())}, paper trades {len(T)}, closed R {T[T.status=='closed'].R.sum():+.2f}")
def update(sub, df, dist, state, evaluate):
    """called from shadow_bot.cycle(). returns alert strings."""
    if os.environ.get("SWING_OFF"): return []
    msgs = []; os.makedirs(DATA, exist_ok=True)
    TR = _load(F_TR, TRC, ["entry_time", "exit_time"]); trades = TR.to_dict("records")
    for t in trades:                                           # refresh paper trades
        was = t["status"]; r = evaluate(df, t); t["status"] = r["status"]; t["mark_R"] = round(r["R"], 3); t["legs"] = r["legs"]
        if r["status"] == "closed":
            t["R"] = round(r["R"], 3); t["exit_time"] = df.index[min(r["exit_idx"], len(df) - 1)]
            if was != "closed": msgs.append(f"PAPER SWING closed {t['sleeve']} {'LONG' if t['dir']==1 else 'SHORT'} -> R {t['R']:+.2f}")
    last = pd.Timestamp(state["swing_last"]) if "swing_last" in state else sub.index[-1]
    days = pd.date_range(sub.index[0].floor("1D"), sub.index[-1].floor("1D") + pd.Timedelta(days=2), freq="1D"); nc = len(sub) - 1; D = None; new = []
    saved = dict(V.TP); V.TP.update(Nh=48, k=1.5)                # the swing sleeve was validated with the ORIGINAL v6 trigger settings (48h lookback, 1.5 ATR stop)
    try:
        for mins in V.TREND_TFS:
            for sgn in (1, -1):
                sg = V.trend_signals(sub, mins, pd.Series(.05 * sgn, index=days), nc, nc)
                for r in sg.itertuples():
                    et = sub.index[r.e]
                    if et <= last: continue
                    dd = dist.reindex([et.floor("1D")]).to_numpy()[0]
                    if np.isfinite(dd) and np.sign(dd) != r.d: new.append((f"T{mins}", int(r.e), int(r.d), float(r.s)))
    finally: V.TP.clear(); V.TP.update(saved)
    for sl, e, d, s in sorted(new, key=lambda x: x[1]):
        et = sub.index[e]; E = float(sub.open.iloc[e]); D = depth_1m() if D is None else D; f = features(D, et); flag = False; note = ""; S4 = np.nan; vals = dict(I1=np.nan, c4h=np.nan, c24h=np.nan, c72h=np.nan); cov = np.nan
        if f is None: note = "no depth data yet (collector needs >=72h)"
        else:
            cov = f["cov"]; S4, vals = score(f, d)
            if not np.isfinite(S4): note = "depth history too short"
            elif cov < 1.0: note = f"collector sees only +-{cov:.2f}% of the book: +-1% band incomplete, not flagged"
            else: flag = S4 >= THR
        pd.DataFrame([dict(entry_time=et, sleeve=sl, dir=d, entry=E, stop_pct=s, I1=vals["I1"], c4h=vals["c4h"], c24h=vals["c24h"], c72h=vals["c72h"], S4=S4, cov_pct=cov, flag=flag, note=note)]).to_csv(F_LOG, mode="a", header=not os.path.exists(F_LOG), index=False)
        if not flag: continue
        mine = [t for t in trades if t["sleeve"] == sl]
        if mine and mine[-1]["status"] != "closed": continue
        if mine:
            xi = df.index.get_loc(mine[-1]["exit_time"]); ei = df.index.get_loc(et) if et in df.index else len(df)
            if ei <= xi + 1: continue
        stop = E * (1 - s) if d == 1 else E * (1 + s)
        trades.append(dict(sleeve=sl, entry_time=et, dir=d, entry=E, stop_pct=s, stop=stop, S4=round(S4, 3), status="open", exit_time=pd.NaT, R=np.nan, mark_R=0.0, legs=""))
        msgs.append(f"PAPER SWING (counter-trend, depth score {S4:.2f}) {sl} {'LONG' if d==1 else 'SHORT'} @ {E:.0f} stop {stop:.0f} ({s*100:.2f}%). NOT a live signal: logged for review.")
    state["swing_last"] = str(sub.index[-1]); pd.DataFrame(trades, columns=TRC).to_csv(F_TR, index=False); return msgs
