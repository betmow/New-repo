# BTC v6 shadow bot
Generates the v6 signals live and follows them as VIRTUAL trades. No orders, no API keys, no account needed.

Sleeves: R = reversal (ungated), T30 / T150 / T330 = trend breakout on 30-minute / 2.5-hour / 5.5-hour candles. One virtual position per sleeve.

## Install (MacBook, Terminal)
1. Copy this folder to the Mac, e.g. ~/btc-shadow   (v6engine.py, shadow_bot.py, requirements.txt)
2. `cd ~/btc-shadow && python3 -m pip install -r requirements.txt`
3. Self-test offline (optional): needs a history file, see step 4.
4. First run: `python3 shadow_bot.py`  -> downloads BTCUSDT 15m history from Binance (about 5 minutes, once), then checks for signals.
5. Keep it running: `caffeinate -s python3 shadow_bot.py --loop`  (keeps the Mac awake; lid open, charger on)
   Auto-start at login: edit YOURNAME in com.btcshadow.plist, copy to ~/Library/LaunchAgents/, run `launchctl load ~/Library/LaunchAgents/com.btcshadow.plist`
6. Look at results any time: `python3 shadow_bot.py --status`  (full log: shadow_data/shadow_trades.csv and shadow_data/shadow.log)

## Telegram alerts
1. In Telegram open @BotFather, send /newbot, choose a name, copy the token.
2. Open your new bot, press Start and send "hi".
3. In the bot folder run `python3 tg_setup.py YOUR_TOKEN` (on the VPS: `venv/bin/python tg_setup.py YOUR_TOKEN`). It sends a test message and writes .env.
4. Restart the bot (`sudo systemctl restart btcshadow` on the VPS).
You get a message at start, on every new signal, on every close, if data is more than 45 minutes behind, and one short daily check around 06:00 UTC.

## What it checks
- Signals are computed by the same rules as the backtest (verified: the standalone engine reproduces all 375 backtest trades with identical entries and R; a bar-by-bar replay of Sep 10 - Oct 19 2026 produced 19/19 identical trades).
- "size_btc_at_risk" = BTC size for a $1 risk per trade after fees (RISK_USD env var changes it). Information only.
- Entry price = open of the 15m bar after the signal candle closes. Costs 5 bp per side, funding ignored, same as the backtest.

## Known limits
- Network parts (download, open-interest history) are the only code not tested offline: if the first run prints an error, send it to me.
- Open interest history from the API covers the last 500 bars; the reversal sleeve needs 24h of it. The bot saves what it downloads.
- Run on one machine only. If you stop it for a while, it catches up on missed bars (virtual trades opened late are marked by the entry time).

## VPS install (Ubuntu 24.04, Germany/Finland, not US)
1. Copy the folder to the server (Termius SFTP, or `scp -r btc-shadow user@SERVER_IP:~`).
2. `ssh user@SERVER_IP`, then `cd btc-shadow && bash setup_vps.sh`
3. Logs: `journalctl -u btcshadow -f`   Results: `venv/bin/python shadow_bot.py --status`
The first start downloads the history (about 5 minutes) before the first check.

## Experimental sizing tier (logged only)
Each signal also shows the RSI of 5-hour candles in the trade direction and a tier: A = trend trade with RSI5h >= 60 (suggested size x1.25), B = other trend trade (x0.85), R = reversal (x1.0). This is a hypothesis from the backtest (see report); the bot only records it so we can test it forward.


## Order-book collector (added)
- `collector.py` keeps live order books for BTCUSDT/ETHUSDT (spot + perp) and writes a row every 5 s to `collect/<market>_<sym>/<day>.csv.gz`
  (depth in USD within 0.1/0.25/0.5/1/2/3/5 %, imbalance inputs, spread, taker buy/sell volume, big trades) + liquidations (`collect/liq`) + funding/OI (`collect/meta_*`).
- `python collector.py --probe` : runs 75 s and prints how far from price each book is really seen (`coverage %`). Run it first. If perp coverage is < 5 %, the 5 % bands are under-counted: tell me the numbers.
- `rollup_push.py` : nightly (cron) turns yesterday into 1-minute files and pushes them to GitHub under `collect1m/`. Put `GH_TOKEN=` (fine-grained token, Contents read/write on the repo) and `GH_REPO=Betmow/new-repo` in `.env`.
- Server must be in Europe (Frankfurt/Helsinki). Binance blocks US IPs.


## v7 update (read this first)
- **Signals now use Binance USD-M PERP prices** (what you actually trade), with the v7 trend settings: 72 h lookback, 1.0 ATR stop. Verified: replay of Aug-Oct 2026 gives the same 28 trades and the same R as the backtest.
- **Delete `shadow_data/btc_15min.csv` if you ran an older version.** v7 writes `btc_15min_perp.csv` and downloads about 4 years of perp history the first time (a few minutes).
- **Swing sleeve (paper only):** `swing.py` logs every counter-trend breakout to `shadow_data/swing_log.csv` with its depth score; signals with score >= 0.8 become paper trades in `shadow_data/swing_trades.csv` and send a Telegram message that starts with "PAPER SWING". It never trades. It needs the collector running for 72 hours before a score exists.
- **First checks on the server** (in this order):
  1. `python collector.py --probe` -> send me the coverage lines.
  2. After 2 full days of collecting: `python depth_check.py` -> must print PASS (collector's +-1% depth matches Binance's own file). If it prints FAIL, send me the line; the swing flag is not trustworthy until fixed.
  3. After 3+ days: `python shadow_bot.py --status` shows the swing summary.
