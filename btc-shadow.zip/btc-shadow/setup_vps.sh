#!/usr/bin/env bash
# Run once on a fresh Ubuntu/Debian server, from inside the folder that holds shadow_bot.py:   bash setup_vps.sh
set -e
APP="$(pwd)"; USER_NAME="$(whoami)"
sudo apt-get update -y && sudo apt-get install -y python3 python3-venv python3-pip ufw unattended-upgrades
python3 -m venv "$APP/venv" && "$APP/venv/bin/pip" install -q -r requirements.txt
# firewall: only SSH in
sudo ufw allow OpenSSH && sudo ufw --force enable
# service: starts at boot, restarts if it crashes
sudo tee /etc/systemd/system/btcshadow.service >/dev/null <<UNIT
[Unit]
Description=BTC v6 shadow bot
After=network-online.target
Wants=network-online.target
[Service]
User=$USER_NAME
WorkingDirectory=$APP
EnvironmentFile=-$APP/.env
ExecStart=$APP/venv/bin/python shadow_bot.py --loop
Restart=always
RestartSec=30
[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload && sudo systemctl enable --now btcshadow
# order-book collector (BTC+ETH, spot+perp): second service, same server
sudo tee /etc/systemd/system/btccollector.service >/dev/null <<UNIT
[Unit]
Description=Binance order-book collector
After=network-online.target
Wants=network-online.target
[Service]
User=$USER_NAME
WorkingDirectory=$APP
ExecStart=$APP/venv/bin/python collector.py
Restart=always
RestartSec=20
[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload && sudo systemctl enable --now btccollector
# nightly: roll yesterday into 1-minute files and push them to GitHub (needs GH_TOKEN and GH_REPO in .env)
( crontab -l 2>/dev/null | grep -v rollup_push ; echo "10 0 * * * cd $APP && $APP/venv/bin/python rollup_push.py >> $APP/rollup.log 2>&1" ) | crontab -
echo "Collector:  journalctl -u btccollector -f     First check (after 2 min):  ls -R $APP/collect | head"
echo "Started. Watch it:  journalctl -u btcshadow -f      Results:  $APP/venv/bin/python shadow_bot.py --status"
echo "Telegram alerts (optional): put TG_TOKEN=... and TG_CHAT=... lines in $APP/.env then: sudo systemctl restart btcshadow"
